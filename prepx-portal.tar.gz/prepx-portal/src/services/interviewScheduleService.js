/**
 * Interview Schedule Service
 * Manages interviewers, availability, and interview bookings
 */

const DB_NAME = "prepx_interview_db";
const DB_VERSION = 2;
const INTERVIEWERS_STORE = "interviewers";
const BOOKINGS_STORE = "interview_bookings";

let idbInstance = null;
let initPromise = null;

/**
 * Initialize Interview Schedule stores in IndexedDB
 */
export async function initInterviewDB() {
  return new Promise((resolve, reject) => {
    console.log(`📊 Opening IndexedDB: ${DB_NAME} v${DB_VERSION}`);
    
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      console.error("❌ DB open error:", request.error);
      reject(request.error);
    };
    
    request.onsuccess = () => {
      console.log("✅ Database opened successfully");
      idbInstance = request.result;
      resolve(idbInstance);
    };

    request.onupgradeneeded = (event) => {
      console.log("🔧 Database upgrade needed");
      const database = event.target.result;

      // Create interviewers store
      if (!database.objectStoreNames.contains(INTERVIEWERS_STORE)) {
        console.log(`📝 Creating store: ${INTERVIEWERS_STORE}`);
        const interviewerStore = database.createObjectStore(INTERVIEWERS_STORE, { keyPath: "id" });
        interviewerStore.createIndex("name", "name", { unique: false });
      }

      // Create bookings store
      if (!database.objectStoreNames.contains(BOOKINGS_STORE)) {
        console.log(`📝 Creating store: ${BOOKINGS_STORE}`);
        const bookingStore = database.createObjectStore(BOOKINGS_STORE, { keyPath: "bookingId" });
        bookingStore.createIndex("uid", "uid", { unique: false });
        bookingStore.createIndex("interviewerId", "interviewerId", { unique: false });
      }
    };
  });
}

/**
 * Ensure DB is initialized
 */
async function ensureDB() {
  if (!idbInstance) {
    if (!initPromise) {
      initPromise = initInterviewDB();
    }
    idbInstance = await initPromise;
  }
  return idbInstance;
}

/**
 * Seed sample interviewers
 */
export async function seedInterviewers() {
  const db = await ensureDB();

  const interviewers = [
    {
      id: "int_1",
      name: "Raj Patel",
      title: "Senior Frontend Engineer",
      company: "Tech Corp",
      rating: 4.8,
      reviews: 145,
      expertise: ["React", "JavaScript", "CSS", "Web Performance"],
      bio: "10+ years experience in frontend development. Expert in React and modern web technologies.",
      image: "👨‍💼",
      hourlyRate: 50,
      availability: [
        { date: "2024-04-12", slots: ["10:00", "14:00", "16:00"] },
        { date: "2024-04-13", slots: ["09:00", "11:00", "15:00"] },
        { date: "2024-04-14", slots: ["13:00", "14:30", "17:00"] },
      ]
    },
    {
      id: "int_2",
      name: "Sarah Chen",
      title: "Backend Engineer",
      company: "CloudWare Inc",
      rating: 4.9,
      reviews: 203,
      expertise: ["Node.js", "Python", "Database Design", "System Architecture"],
      bio: "Full-stack engineer with expertise in building scalable backend systems.",
      image: "👩‍💼",
      hourlyRate: 55,
      availability: [
        { date: "2024-04-12", slots: ["11:00", "13:00", "15:30"] },
        { date: "2024-04-13", slots: ["10:00", "14:00", "16:00"] },
        { date: "2024-04-15", slots: ["09:00", "11:30", "14:00"] },
      ]
    },
    {
      id: "int_3",
      name: "Mike Johnson",
      title: "Full Stack Developer",
      company: "StartUp Labs",
      rating: 4.7,
      reviews: 178,
      expertise: ["MERN Stack", "DevOps", "Docker", "AWS"],
      bio: "Passionate about helping juniors transition into tech. Specializes in full-stack development.",
      image: "👨‍💻",
      hourlyRate: 45,
      availability: [
        { date: "2024-04-12", slots: ["09:00", "10:30", "16:00"] },
        { date: "2024-04-14", slots: ["11:00", "13:30", "15:00"] },
        { date: "2024-04-15", slots: ["10:00", "12:00", "16:00"] },
      ]
    },
    {
      id: "int_4",
      name: "Priya Sharma",
      title: "Data Science Lead",
      company: "AI Solutions",
      rating: 4.6,
      reviews: 89,
      expertise: ["Python", "Machine Learning", "SQL", "Data Analysis"],
      bio: "Expert in data science and machine learning interviews. Helps candidates land data science roles.",
      image: "👩‍🔬",
      hourlyRate: 60,
      availability: [
        { date: "2024-04-13", slots: ["12:00", "14:30", "16:30"] },
        { date: "2024-04-14", slots: ["10:00", "14:00"] },
        { date: "2024-04-15", slots: ["11:00", "13:00", "15:30"] },
      ]
    },
    {
      id: "int_5",
      name: "Alex Kumar",
      title: "DevOps Engineer",
      company: "InfraTech",
      rating: 4.5,
      reviews: 112,
      expertise: ["Kubernetes", "Docker", "CI/CD", "Cloud Architecture"],
      bio: "Focus on infrastructure and DevOps role preparation.",
      image: "👨‍🔧",
      hourlyRate: 50,
      availability: [
        { date: "2024-04-12", slots: ["15:00", "17:00"] },
        { date: "2024-04-13", slots: ["09:00", "11:00", "13:00"] },
        { date: "2024-04-15", slots: ["14:00", "16:00"] },
      ]
    }
  ];

  return new Promise((resolve, reject) => {
    const tx = db.transaction(INTERVIEWERS_STORE, "readwrite");
    const store = tx.objectStore(INTERVIEWERS_STORE);

    // Add all interviewers (will overwrite duplicates)
    interviewers.forEach(interviewer => {
      store.put(interviewer);
    });

    tx.oncomplete = () => {
      console.log("✅ Interviewers seeded successfully");
      resolve(true);
    };
    
    tx.onerror = () => {
      console.error("❌ Error seeding interviewers:", tx.error);
      reject(tx.error);
    };
  });
}

/**
 * Get all interviewers
 */
export async function getAllInterviewers() {
  const db = await ensureDB();

  return new Promise((resolve, reject) => {
    const tx = db.transaction(INTERVIEWERS_STORE, "readonly");
    const store = tx.objectStore(INTERVIEWERS_STORE);
    const request = store.getAll();

    request.onsuccess = () => {
      console.log("✅ Retrieved interviewers:", request.result);
      resolve(request.result);
    };
    
    request.onerror = () => {
      console.error("❌ Error retrieving interviewers:", request.error);
      reject(request.error);
    };
  });
}

/**
 * Get single interviewer by ID
 */
export async function getInterviewerById(id) {
  const db = await ensureDB();

  return new Promise((resolve, reject) => {
    const tx = db.transaction(INTERVIEWERS_STORE, "readonly");
    const store = tx.objectStore(INTERVIEWERS_STORE);
    const request = store.get(id);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Book an interview slot
 */
export async function bookInterviewSlot(uid, interviewerId, date, time) {
  const db = await ensureDB();

  const booking = {
    bookingId: `booking_${Date.now()}`,
    uid,
    interviewerId,
    date,
    time,
    status: "confirmed",
    bookedAt: new Date().toISOString(),
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(BOOKINGS_STORE, "readwrite");
    const store = tx.objectStore(BOOKINGS_STORE);
    const request = store.add(booking);

    request.onsuccess = () => resolve(booking);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Get user's interview bookings
 */
export async function getUserBookings(uid) {
  const db = await ensureDB();

  return new Promise((resolve, reject) => {
    const tx = db.transaction(BOOKINGS_STORE, "readonly");
    const store = tx.objectStore(BOOKINGS_STORE);
    const index = store.index("uid");
    const request = index.getAll(uid);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Cancel a booking
 */
export async function cancelBooking(bookingId) {
  const db = await ensureDB();

  return new Promise((resolve, reject) => {
    const tx = db.transaction(BOOKINGS_STORE, "readwrite");
    const store = tx.objectStore(BOOKINGS_STORE);
    const request = store.delete(bookingId);

    request.onsuccess = () => resolve(true);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Reschedule a booking
 */
export async function rescheduleBooking(bookingId, newDate, newTime) {
  const db = await ensureDB();

  return new Promise((resolve, reject) => {
    const tx = db.transaction(BOOKINGS_STORE, "readwrite");
    const store = tx.objectStore(BOOKINGS_STORE);
    const request = store.get(bookingId);

    request.onsuccess = () => {
      const booking = request.result;
      if (booking) {
        booking.date = newDate;
        booking.time = newTime;
        booking.rescheduledAt = new Date().toISOString();
        const updateRequest = store.put(booking);
        updateRequest.onsuccess = () => resolve(booking);
        updateRequest.onerror = () => reject(updateRequest.error);
      } else {
        reject(new Error("Booking not found"));
      }
    };
    request.onerror = () => reject(request.error);
  });
}

/**
 * Get all interview bookings (for admin)
 */
export async function getAllBookings() {
  const db = await ensureDB();

  return new Promise((resolve, reject) => {
    const tx = db.transaction(BOOKINGS_STORE, "readonly");
    const store = tx.objectStore(BOOKINGS_STORE);
    const request = store.getAll();

    request.onsuccess = () => {
      console.log("✅ Retrieved all bookings:", request.result);
      resolve(request.result || []);
    };
    
    request.onerror = () => {
      console.error("❌ Error retrieving all bookings:", request.error);
      reject(request.error);
    };
  });
}
