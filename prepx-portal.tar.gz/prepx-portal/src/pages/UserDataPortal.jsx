import React, { useState, useEffect } from 'react';
import { userDataService } from '../services/userDataService.js';
import { getAllBookings, getAllInterviewers } from '../services/interviewScheduleService.js';
import '../styles/UserDataPortal.css';

export default function UserDataPortal() {
  const [currentPage, setCurrentPage] = useState(1);
  const [activeTab, setActiveTab] = useState('users'); // 'users' or 'bookings'
  const [pageData, setPageData] = useState({
    users: [],
    totalCount: 0,
    totalPages: 0,
    currentPage: 1,
    pageSize: 50,
    hasMore: false
  });
  const [bookings, setBookings] = useState([]);
  const [interviewers, setInterviewers] = useState({});
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState({ type: '', text: '' });

  // Load data on mount
  useEffect(() => {
    if (activeTab === 'users') {
      loadUsers();
    } else {
      loadBookings();
    }
  }, [activeTab, currentPage]);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const data = await userDataService.getPaginatedUsers(currentPage, 50);
      setPageData(data);
      setMessage({ type: '', text: '' });
    } catch (error) {
      console.error('Error loading users:', error);
      setMessage({
        type: 'error',
        text: 'Failed to load users. Please try again.'
      });
    } finally {
      setLoading(false);
    }
  };

  const loadBookings = async () => {
    try {
      setLoading(true);
      console.log("📅 Loading all bookings...");
      
      // Load bookings and interviewers
      const [allBookings, allInterviewers] = await Promise.all([
        getAllBookings(),
        getAllInterviewers()
      ]);
      
      console.log("✅ Bookings loaded:", allBookings?.length || 0);
      console.log("✅ Interviewers loaded:", allInterviewers?.length || 0);
      
      setBookings(allBookings || []);
      
      // Create interviewer map for quick lookup
      const interviewerMap = {};
      if (allInterviewers && allInterviewers.length > 0) {
        allInterviewers.forEach(int => {
          interviewerMap[int.id] = int;
        });
      }
      setInterviewers(interviewerMap);
      
      setMessage({ type: '', text: '' });
    } catch (error) {
      console.error('Error loading bookings:', error);
      setBookings([]);
      setMessage({
        type: 'error',
        text: 'Failed to load bookings. Please try again.'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    try {
      setMessage({ type: 'loading', text: 'Generating CSV file...' });
      await userDataService.downloadAsCSV();
      setMessage({
        type: 'success',
        text: `✅ Downloaded! ${pageData.totalCount} users exported to CSV`
      });
      setTimeout(() => setMessage({ type: '', text: '' }), 3000);
    } catch (error) {
      console.error('Error downloading:', error);
      setMessage({
        type: 'error',
        text: 'Failed to download file. Please try again.'
      });
    }
  };

  const downloadBookingsAsCSV = () => {
    try {
      if (bookings.length === 0) {
        setMessage({ type: 'error', text: 'No bookings to download' });
        return;
      }

      // Prepare CSV data
      const headers = ['Booking ID', 'User ID', 'Interviewer', 'Date', 'Time', 'Status', 'Cost', 'Booked At'];
      const rows = bookings.map(booking => [
        booking.bookingId,
        booking.uid || 'N/A',
        interviewers[booking.interviewerId]?.name || 'Unknown',
        booking.date,
        booking.time,
        booking.status,
        `$${interviewers[booking.interviewerId]?.hourlyRate || 'N/A'}`,
        new Date(booking.bookedAt).toLocaleString()
      ]);

      // Create CSV
      let csvContent = headers.join(',') + '\n';
      rows.forEach(row => {
        csvContent += row.map(cell => `"${cell}"`).join(',') + '\n';
      });

      // Download
      const element = document.createElement('a');
      element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent));
      element.setAttribute('download', `interview_bookings_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

      setMessage({
        type: 'success',
        text: `✅ Downloaded! ${bookings.length} bookings exported to CSV`
      });
      setTimeout(() => setMessage({ type: '', text: '' }), 3000);
    } catch (error) {
      console.error('Error downloading bookings:', error);
      setMessage({
        type: 'error',
        text: 'Failed to download file. Please try again.'
      });
    }
  };

  const handleRefresh = () => {
    setCurrentPage(1);
    if (activeTab === 'users') {
      loadUsers();
    } else {
      loadBookings();
    }
  };

  return (
    <div className="user-data-portal">
      {/* Header */}
      <div className="udp-header">
        <h1>📊 User Data Portal</h1>
        <p>View and manage all user accounts and interview bookings</p>
      </div>

      {/* Tab Navigation */}
      <div className="udp-tabs">
        <button
          className={`tab-btn ${activeTab === 'users' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('users');
            setCurrentPage(1);
          }}
        >
          👥 Users ({pageData.totalCount})
        </button>
        <button
          className={`tab-btn ${activeTab === 'bookings' ? 'active' : ''}`}
          onClick={() => {
            setActiveTab('bookings');
            setCurrentPage(1);
          }}
        >
          📅 Interview Bookings ({bookings.length})
        </button>
      </div>

      {/* Stats Bar */}
      <div className="udp-stats">
        <div className="stat-box">
          <div className="stat-label">
            {activeTab === 'users' ? 'Total Users' : 'Total Bookings'}
          </div>
          <div className="stat-value">
            {activeTab === 'users' ? pageData.totalCount : bookings.length}
          </div>
        </div>
        <div className="stat-box">
          <div className="stat-label">
            {activeTab === 'users' ? 'Current Page' : 'Status'}
          </div>
          <div className="stat-value">
            {activeTab === 'users'
              ? `${pageData.currentPage} / ${pageData.totalPages || 1}`
              : 'All Confirmed'}
          </div>
        </div>
        <div className="stat-box">
          <div className="stat-label">Showing</div>
          <div className="stat-value">
            {activeTab === 'users'
              ? `${pageData.users.length}/${pageData.pageSize}`
              : `${bookings.length} bookings`}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="udp-actions">
        {activeTab === 'users' ? (
          <button
            className="btn btn-download"
            onClick={handleDownload}
            disabled={pageData.totalCount === 0}
            title={pageData.totalCount === 0 ? 'No users to download' : 'Download all users as CSV'}
          >
            📥 Download All Users as CSV
          </button>
        ) : (
          <button
            className="btn btn-download"
            onClick={downloadBookingsAsCSV}
            disabled={bookings.length === 0}
            title={bookings.length === 0 ? 'No bookings to download' : 'Download all bookings as CSV'}
          >
            📥 Download All Bookings as CSV
          </button>
        )}
        <button
          className="btn btn-refresh"
          onClick={handleRefresh}
          disabled={loading}
        >
          🔄 Refresh
        </button>
      </div>

      {/* Message Display */}
      {message.text && (
        <div className={`message message-${message.type}`}>
          {message.text}
        </div>
      )}

      {/* Table Container */}
      <div className="udp-table-container">
        {loading ? (
          <div className="loading">Loading {activeTab === 'users' ? 'users' : 'bookings'}...</div>
        ) : activeTab === 'users' ? (
          // USERS TABLE
          pageData.users.length === 0 ? (
            <div className="empty-state">
              <h3>📭 No Users Yet</h3>
              <p>Sign up some users to see them here!</p>
            </div>
          ) : (
            <>
              <table className="udp-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Name</th>
                    <th>Date of Birth</th>
                    <th>Account Created</th>
                    <th>Registered</th>
                  </tr>
                </thead>
                <tbody>
                  {pageData.users.map((user, index) => (
                    <tr key={user.uid} className={index % 2 === 0 ? 'even' : 'odd'}>
                      <td className="row-number">
                        {(pageData.currentPage - 1) * pageData.pageSize + index + 1}
                      </td>
                      <td className="email-cell">{user.email}</td>
                      <td className="password-cell">
                        <span className="password-masked">•••••••••</span>
                        <span className="password-actual">{user.password}</span>
                      </td>
                      <td>{user.name}</td>
                      <td>{user.dob}</td>
                      <td className="date-cell">{user.accountCreated}</td>
                      <td>
                        <span className={`badge ${user.registered === 'Yes' ? 'registered' : 'pending'}`}>
                          {user.registered}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Pagination */}
              <div className="udp-pagination">
                <button
                  className="btn btn-nav"
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={pageData.currentPage === 1}
                >
                  ← Previous
                </button>

                <div className="page-info">
                  Page {pageData.currentPage} of {pageData.totalPages}
                </div>

                <button
                  className="btn btn-nav"
                  onClick={() => setCurrentPage(p => Math.min(pageData.totalPages, p + 1))}
                  disabled={!pageData.hasMore}
                >
                  Next →
                </button>
              </div>
            </>
          )
        ) : (
          // BOOKINGS TABLE
          bookings.length === 0 ? (
            <div className="empty-state">
              <h3>📭 No Bookings Yet</h3>
              <p>Interview bookings will appear here</p>
            </div>
          ) : (
            <table className="udp-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Booking ID</th>
                  <th>User ID</th>
                  <th>Interviewer</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Duration</th>
                  <th>Cost</th>
                  <th>Status</th>
                  <th>Booked At</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((booking, index) => {
                  const interviewer = interviewers[booking.interviewerId];
                  return (
                    <tr key={booking.bookingId} className={index % 2 === 0 ? 'even' : 'odd'}>
                      <td className="row-number">{index + 1}</td>
                      <td className="booking-id">{booking.bookingId}</td>
                      <td className="user-id">{booking.uid || 'N/A'}</td>
                      <td className="interviewer-name">
                        {interviewer ? (
                          <>
                            <span className="avatar">{interviewer.image}</span>
                            {interviewer.name}
                          </>
                        ) : (
                          'Unknown'
                        )}
                      </td>
                      <td className="date-cell">{booking.date}</td>
                      <td className="time-cell">{booking.time}</td>
                      <td>60 min</td>
                      <td className="cost-cell">
                        ${interviewer?.hourlyRate || 'N/A'}
                      </td>
                      <td>
                        <span className={`badge ${booking.status.toLowerCase()}`}>
                          {booking.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="date-cell">
                        {new Date(booking.bookedAt).toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )
        )}
      </div>

      {/* Info Section */}
      <div className="udp-info">
        <h3>📋 About This Portal</h3>
        <ul>
          <li>
            {activeTab === 'users'
              ? 'Shows up to 50 users per page'
              : 'Shows all interview bookings in real-time'}
          </li>
          <li>Click "Download All as CSV" to export data</li>
          <li>CSV file opens directly in Excel</li>
          {activeTab === 'users' && (
            <>
              <li>Password shown as dots for security (hover to see)</li>
              <li>Updates automatically when new users sign up</li>
            </>
          )}
          {activeTab === 'bookings' && (
            <>
              <li>Shows all confirmed interview bookings</li>
              <li>Updates in real-time as bookings are created</li>
            </>
          )}
          <li>Generated: {new Date().toLocaleString()}</li>
        </ul>
      </div>
    </div>
  );
}
