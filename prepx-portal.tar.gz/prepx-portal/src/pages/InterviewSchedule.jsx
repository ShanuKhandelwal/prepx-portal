import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthProvider";
import {
  getAllInterviewers,
  getInterviewerById,
  bookInterviewSlot,
  getUserBookings,
  cancelBooking,
  rescheduleBooking,
  seedInterviewers,
} from "../services/interviewScheduleService";
import "../styles/InterviewSchedule.css";

export default function InterviewSchedule() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [interviewers, setInterviewers] = useState([]);
  const [userBookings, setUserBookings] = useState([]);
  const [selectedInterviewer, setSelectedInterviewer] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [view, setView] = useState("browse"); // browse, book, mybookings
  const [loading, setLoading] = useState(true);
  const [expandedInterviewer, setExpandedInterviewer] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");

  // Mock data as fallback
  const mockInterviewers = [
    {
      id: "int_1",
      name: "Raj Patel",
      title: "Senior Frontend Engineer",
      company: "Tech Corp",
      rating: 4.8,
      reviews: 145,
      expertise: ["React", "JavaScript", "CSS", "Web Performance"],
      bio: "10+ years experience in frontend development.",
      image: "👨‍💼",
      hourlyRate: 50,
      availability: [
        { date: "2024-04-12", slots: ["10:00", "14:00", "16:00"] },
        { date: "2024-04-13", slots: ["09:00", "11:00", "15:00"] },
        { date: "2024-04-14", slots: ["13:00", "14:30", "17:00"] },
      ]
    },
    {
      id: "int_2",
      name: "Sarah Chen",
      title: "Backend Engineer",
      company: "CloudWare Inc",
      rating: 4.9,
      reviews: 203,
      expertise: ["Node.js", "Python", "Database Design", "System Architecture"],
      bio: "Full-stack engineer with expertise in building scalable backend systems.",
      image: "👩‍💼",
      hourlyRate: 55,
      availability: [
        { date: "2024-04-12", slots: ["11:00", "13:00", "15:30"] },
        { date: "2024-04-13", slots: ["10:00", "14:00", "16:00"] },
        { date: "2024-04-15", slots: ["09:00", "11:30", "14:00"] },
      ]
    },
    {
      id: "int_3",
      name: "Mike Johnson",
      title: "Full Stack Developer",
      company: "StartUp Labs",
      rating: 4.7,
      reviews: 178,
      expertise: ["MERN Stack", "DevOps", "Docker", "AWS"],
      bio: "Full-stack development specialist.",
      image: "👨‍💻",
      hourlyRate: 45,
      availability: [
        { date: "2024-04-12", slots: ["09:00", "10:30", "16:00"] },
        { date: "2024-04-14", slots: ["11:00", "13:30", "15:00"] },
        { date: "2024-04-15", slots: ["10:00", "12:00", "16:00"] },
      ]
    },
    {
      id: "int_4",
      name: "Priya Sharma",
      title: "Data Science Lead",
      company: "AI Solutions",
      rating: 4.6,
      reviews: 89,
      expertise: ["Python", "Machine Learning", "SQL", "Data Analysis"],
      bio: "Data science and ML interviews.",
      image: "👩‍🔬",
      hourlyRate: 60,
      availability: [
        { date: "2024-04-13", slots: ["12:00", "14:30", "16:30"] },
        { date: "2024-04-14", slots: ["10:00", "14:00"] },
        { date: "2024-04-15", slots: ["11:00", "13:00", "15:30"] },
      ]
    },
    {
      id: "int_5",
      name: "Alex Kumar",
      title: "DevOps Engineer",
      company: "InfraTech",
      rating: 4.5,
      reviews: 112,
      expertise: ["Kubernetes", "Docker", "CI/CD", "Cloud Architecture"],
      bio: "DevOps role preparation.",
      image: "👨‍🔧",
      hourlyRate: 50,
      availability: [
        { date: "2024-04-12", slots: ["15:00", "17:00"] },
        { date: "2024-04-13", slots: ["09:00", "11:00", "13:00"] },
        { date: "2024-04-15", slots: ["14:00", "16:00"] },
      ]
    }
  ];

  // Load data
  useEffect(() => {
    const loadData = async () => {
      try {
        console.log("🔄 Starting to load interview data...");
        
        // Try to seed interviewers
        try {
          await seedInterviewers();
          console.log("✅ Interviewers seeded successfully");
        } catch (seedError) {
          console.error("⚠️ Seed error:", seedError);
        }
        
        // Try to get from database
        try {
          await new Promise(resolve => setTimeout(resolve, 150));
          const data = await getAllInterviewers();
          console.log("✅ DB Query Result - Count:", data?.length, "Data:", data);
          
          if (data && data.length > 0) {
            console.log("✅ Using data from database");
            setInterviewers(data);
          } else {
            console.log("📌 Database returned empty, using mock data");
            setInterviewers(mockInterviewers);
          }
        } catch (dbError) {
          console.error("❌ Database error:", dbError);
          console.log("📌 Using mock data as fallback");
          setInterviewers(mockInterviewers);
        }

        // Load user bookings
        if (user?.uid) {
          try {
            const bookings = await getUserBookings(user.uid);
            console.log("✅ Bookings loaded:", bookings?.length || 0);
            setUserBookings(bookings || []);
          } catch (bookError) {
            console.error("⚠️ Booking load error:", bookError);
            setUserBookings([]);
          }
        }
      } catch (error) {
        console.error("❌ Critical error:", error);
        setInterviewers(mockInterviewers);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [user]);

  const handleBookInterview = async () => {
    if (!selectedInterviewer || !selectedDate || !selectedTime) {
      alert("Please select an interviewer, date, and time");
      return;
    }

    try {
      const booking = await bookInterviewSlot(
        user.uid,
        selectedInterviewer.id,
        selectedDate,
        selectedTime
      );

      setUserBookings([...userBookings, booking]);
      setSuccessMessage("Interview booked successfully! 🎉");
      setTimeout(() => {
        setSuccessMessage("");
        setSelectedInterviewer(null);
        setSelectedDate(null);
        setSelectedTime(null);
        setView("mybookings");
      }, 2000);
    } catch (error) {
      alert("Error booking interview: " + error.message);
    }
  };

  const handleCancelBooking = async (bookingId) => {
    if (!window.confirm("Are you sure you want to cancel this booking?")) return;

    try {
      await cancelBooking(bookingId);
      setUserBookings(userBookings.filter((b) => b.bookingId !== bookingId));
      setSuccessMessage("Booking cancelled");
      setTimeout(() => setSuccessMessage(""), 2000);
    } catch (error) {
      alert("Error cancelling booking: " + error.message);
    }
  };

  const getAvailableSlots = (interviewer, date) => {
    const availability = interviewer.availability.find((a) => a.date === date);
    return availability ? availability.slots : [];
  };

  const getInterviewerName = (interviewerId) => {
    const interviewer = interviewers.find((i) => i.id === interviewerId);
    return interviewer ? interviewer.name : "Unknown";
  };

  if (loading) {
    return <div className="interview-schedule-container">Loading...</div>;
  }

  return (
    <div className="interview-schedule">
      {/* Header */}
      <div className="interview-header">
        <button className="btn btn-outline btn-sm" onClick={() => navigate("/fresher")}>
          ← Back to Dashboard
        </button>
        <h1>📅 Interview Schedule</h1>
        <div className="interview-nav-buttons">
          <button
            className={`nav-btn ${view === "browse" ? "active" : ""}`}
            onClick={() => setView("browse")}
          >
            Browse Interviewers
          </button>
          <button
            className={`nav-btn ${view === "mybookings" ? "active" : ""}`}
            onClick={() => setView("mybookings")}
          >
            My Bookings ({userBookings.length})
          </button>
        </div>
      </div>

      <div className="interview-container">
        {successMessage && (
          <div className="success-message">{successMessage}</div>
        )}

        {/* Browse Interviewers View */}
        {view === "browse" && (
          <div className="browse-view">
            {!selectedInterviewer ? (
              <>
                <h2>Available Interviewers</h2>
                <p className="subtext">
                  Choose an interviewer and book a mock interview to practice
                </p>

                <div className="interviewers-grid">
                  {interviewers.map((interviewer) => (
                    <div
                      key={interviewer.id}
                      className="interviewer-card"
                      onClick={() => setExpandedInterviewer(
                        expandedInterviewer === interviewer.id ? null : interviewer.id
                      )}
                    >
                      <div className="interviewer-header">
                        <div className="interviewer-avatar">{interviewer.image}</div>
                        <div className="interviewer-info">
                          <h3>{interviewer.name}</h3>
                          <p className="title">{interviewer.title}</p>
                          <p className="company">{interviewer.company}</p>
                        </div>
                      </div>

                      <div className="rating-section">
                        <span className="stars">⭐ {interviewer.rating}</span>
                        <span className="reviews">({interviewer.reviews} reviews)</span>
                      </div>

                      <div style={{ fontSize: '13px', color: '#4caf50', fontWeight: '600', marginBottom: '10px' }}>
                        📅 {interviewer.availability.length} dates available
                      </div>

                      {expandedInterviewer === interviewer.id && (
                        <div className="interviewer-expanded">
                          <p className="bio">{interviewer.bio}</p>
                          <div className="expertise">
                            <strong>Expertise:</strong>
                            <div className="tags">
                              {interviewer.expertise.map((skill, idx) => (
                                <span key={idx} className="tag">
                                  {skill}
                                </span>
                              ))}
                            </div>
                          </div>
                          <div className="rate-info">
                            <strong>Rate:</strong> ${interviewer.hourlyRate}/hour
                          </div>
                          <button
                            className="btn btn-primary"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedInterviewer(interviewer);
                            }}
                          >
                            Book Interview
                          </button>
                        </div>
                      )}

                      {expandedInterviewer !== interviewer.id && (
                        <div className="feature-preview">
                          Click to expand <span>→</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </>
            ) : (
              /* Booking Form */
              <div className="booking-form">
                <button
                  className="btn btn-outline btn-sm"
                  onClick={() => {
                    setSelectedInterviewer(null);
                    setSelectedDate(null);
                    setSelectedTime(null);
                  }}
                >
                  ← Back to List
                </button>

                <h2>Book an Interview with {selectedInterviewer.name}</h2>

                {/* Interviewer Details */}
                <div className="booking-interviewer-card">
                  <div className="booking-info">
                    <div className="avatar">{selectedInterviewer.image}</div>
                    <div className="details">
                      <h3>{selectedInterviewer.name}</h3>
                      <p>{selectedInterviewer.title} at {selectedInterviewer.company}</p>
                      <p className="rating">
                        ⭐ {selectedInterviewer.rating} ({selectedInterviewer.reviews} reviews)
                      </p>
                    </div>
                  </div>
                </div>

                {/* Date Selection */}
                <div className="booking-section">
                  <h3>Select Date</h3>
                  <div className="date-options">
                    {selectedInterviewer.availability.map((avail) => (
                      <button
                        key={avail.date}
                        className={`date-btn ${selectedDate === avail.date ? "selected" : ""}`}
                        onClick={() => {
                          setSelectedDate(avail.date);
                          setSelectedTime(null);
                        }}
                      >
                        {new Date(avail.date).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Time Selection */}
                {selectedDate && (
                  <div className="booking-section">
                    <h3>Select Time Slot</h3>
                    <div className="time-options">
                      {getAvailableSlots(selectedInterviewer, selectedDate).map(
                        (time) => (
                          <button
                            key={time}
                            className={`time-btn ${selectedTime === time ? "selected" : ""}`}
                            onClick={() => setSelectedTime(time)}
                          >
                            {time}
                          </button>
                        )
                      )}
                    </div>
                  </div>
                )}

                {/* Summary */}
                {selectedDate && selectedTime && (
                  <div className="booking-summary">
                    <h3>Booking Summary</h3>
                    <div className="summary-item">
                      <span>Interviewer:</span>
                      <strong>{selectedInterviewer.name}</strong>
                    </div>
                    <div className="summary-item">
                      <span>Date:</span>
                      <strong>
                        {new Date(selectedDate).toLocaleDateString("en-US", {
                          month: "long",
                          day: "numeric",
                          year: "numeric",
                        })}
                      </strong>
                    </div>
                    <div className="summary-item">
                      <span>Time:</span>
                      <strong>{selectedTime}</strong>
                    </div>
                    <div className="summary-item">
                      <span>Duration:</span>
                      <strong>60 minutes</strong>
                    </div>
                    <div className="summary-item total">
                      <span>Cost:</span>
                      <strong>${selectedInterviewer.hourlyRate}</strong>
                    </div>
                  </div>
                )}

                <button
                  className="btn btn-success btn-lg"
                  onClick={handleBookInterview}
                  disabled={!selectedDate || !selectedTime}
                >
                  Confirm Booking
                </button>
              </div>
            )}
          </div>
        )}

        {/* My Bookings View */}
        {view === "mybookings" && (
          <div className="bookings-view">
            <h2>Your Interview Bookings</h2>
            {userBookings.length === 0 ? (
              <div className="empty-state">
                <p>You haven't booked any interviews yet.</p>
                <button
                  className="btn btn-primary"
                  onClick={() => setView("browse")}
                >
                  Browse Interviewers
                </button>
              </div>
            ) : (
              <div className="bookings-list">
                {userBookings.map((booking) => {
                  const interviewer = interviewers.find(
                    (i) => i.id === booking.interviewerId
                  );
                  return (
                    <div key={booking.bookingId} className="booking-item">
                      <div className="booking-item-header">
                        <h3>{interviewer?.name || "Unknown Interviewer"}</h3>
                        <span className={`status ${booking.status}`}>
                          {booking.status.toUpperCase()}
                        </span>
                      </div>
                      <div className="booking-item-details">
                        <p>
                          <strong>Date:</strong>{" "}
                          {new Date(booking.date).toLocaleDateString("en-US", {
                            month: "long",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </p>
                        <p>
                          <strong>Time:</strong> {booking.time}
                        </p>
                        <p>
                          <strong>Booked on:</strong>{" "}
                          {new Date(booking.bookedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="booking-item-actions">
                        <button
                          className="btn btn-outline btn-sm"
                          onClick={() => {
                            setSelectedInterviewer(interviewer);
                            setView("browse");
                          }}
                        >
                          Reschedule
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleCancelBooking(booking.bookingId)}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
